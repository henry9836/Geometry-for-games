Functions 1-19 are done

Created by Henry Oliver and Andres Villacreces