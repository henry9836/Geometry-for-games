#pragma once

int getint(int inint);

float getfloat(float infloat);


bool testmefunctions();